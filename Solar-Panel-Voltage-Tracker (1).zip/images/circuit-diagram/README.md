# Circuit Diagram

Upload the actual Solar Panel Voltage Tracker circuit diagram into this folder as `solar-voltage-circuit.jpg` (or `.png`) and reference it in the main README. The schematic image supplied in the chat depicts a 555 timer circuit, so it is not included as the project's circuit diagram.
